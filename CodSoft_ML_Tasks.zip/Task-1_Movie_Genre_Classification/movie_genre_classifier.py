import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

# Sample dataset placeholder
data = {
    "plot": [
        "A spaceship travels through space and fights aliens.",
        "A man falls in love with a woman he meets in a coffee shop.",
        "A detective solves a mysterious murder in a small town."
    ],
    "genre": ["Sci-Fi", "Romance", "Mystery"]
}
df = pd.DataFrame(data)

X = df["plot"]
y = df["genre"]

tfidf = TfidfVectorizer()
X_tfidf = tfidf.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_tfidf, y, test_size=0.2, random_state=42)

model = MultinomialNB()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))