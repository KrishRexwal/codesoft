const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const quizzes = [];

app.get('/quizzes', (req, res) => {
  res.json(quizzes);
});

app.post('/quizzes', (req, res) => {
  const quiz = req.body;
  quizzes.push(quiz);
  res.status(201).json({ message: 'Quiz created' });
});

app.listen(4000, () => console.log('Server running on port 4000'));