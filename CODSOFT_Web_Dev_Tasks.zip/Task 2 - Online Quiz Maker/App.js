import React, { useState } from 'react';

const quizData = [
  {
    question: "What is the capital of France?",
    options: ["Berlin", "Paris", "Rome", "Madrid"],
    answer: "Paris"
  },
  {
    question: "Which is the largest planet?",
    options: ["Earth", "Mars", "Jupiter", "Venus"],
    answer: "Jupiter"
  }
];

function App() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (option) => {
    if (option === quizData[current].answer) setScore(score + 1);
    const next = current + 1;
    if (next < quizData.length) setCurrent(next);
    else setShowResult(true);
  };

  return (
    <div style={{ padding: 20 }}>
      {showResult ? (
        <div>
          <h2>Quiz Completed!</h2>
          <p>Your Score: {score}/{quizData.length}</p>
        </div>
      ) : (
        <div>
          <h2>{quizData[current].question}</h2>
          {quizData[current].options.map((opt) => (
            <button key={opt} onClick={() => handleAnswer(opt)}>{opt}</button>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;