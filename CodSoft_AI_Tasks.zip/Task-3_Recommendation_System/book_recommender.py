from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

books = [
    {"title": "The Great Gatsby", "desc": "Classic novel set in the 1920s"},
    {"title": "To Kill a Mockingbird", "desc": "Race and justice in the Deep South"},
    {"title": "1984", "desc": "Dystopian future with totalitarian government"},
    {"title": "The Hobbit", "desc": "Fantasy adventure with a dragon"},
    {"title": "Harry Potter", "desc": "Boy wizard at magical school"},
]

descriptions = [book["desc"] for book in books]
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(descriptions)

def recommend(title):
    titles = [book["title"] for book in books]
    idx = titles.index(title)
    cosine_sim = linear_kernel(tfidf_matrix[idx:idx+1], tfidf_matrix).flatten()
    related_docs_indices = cosine_sim.argsort()[-2::-1]
    print(f"Books similar to '{title}':")
    for i in related_docs_indices[:2]:
        print("-", books[i]["title"])

recommend("1984")