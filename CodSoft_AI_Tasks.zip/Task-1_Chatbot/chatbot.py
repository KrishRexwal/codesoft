def chatbot_response(user_input):
    user_input = user_input.lower()
    
    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I assist you today?"
    elif "how are you" in user_input:
        return "I'm just a bunch of code, but I'm functioning perfectly!"
    elif "your name" in user_input:
        return "I'm CodBot, your AI assistant."
    elif "bye" in user_input:
        return "Goodbye! Have a nice day."
    else:
        return "I'm not sure how to respond to that. Can you rephrase?"

# Run chatbot
if __name__ == "__main__":
    print("CodBot: Hello! Type 'bye' to end the chat.")
    while True:
        user_input = input("You: ")
        if "bye" in user_input.lower():
            print("CodBot:", chatbot_response(user_input))
            break
        print("CodBot:", chatbot_response(user_input))